import os
import requests
import json

# Установка директории, где находятся ваши YAML файлы
directory_path = "end-points"

# OpenRouter API details
api_key = "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"
base_url = "https://openrouter.ai/api/v1"
headers = {
    "Authorization": f"Bearer {api_key}",
}

def read_yaml_content(file_path):
    """Читает весь контент YAML файла как строку."""
    with open(file_path, 'r') as file:
        return file.read()

def generate_test_cases(yaml_content, test_type):
    """Generates test cases based on the type of testing specified."""
    prompt = f"""ROLE: You are an API testing engineer. Given the endpoint configuration in YAML:
    {yaml_content}
    Write {test_type} test cases. Organize the test cases in JSON format with columns: Test Case ID, Test Description, Input, Expected Output, Remarks. RETURN ONLY JSON FORMAT OR YOU WILL GET A PENALTY"""
    
    data = {
        "model": "openai/gpt-4-turbo",
        "prompt": prompt,
        "temperature": 0.5,
    }
    
    response = requests.post(f"{base_url}/completions", headers=headers, json=data)
    if response.status_code == 200:
        response_content = response.json()
        if "choices" in response_content and response_content["choices"]:
            generated_text = response_content["choices"][0]["text"]
            # Remove markdown code block syntax that might wrap the JSON
            if generated_text.startswith("```json") and generated_text.endswith("```"):
                # Slice off the first 7 characters and the last 3 characters
                cleaned_text = generated_text[7:-3].strip()
                try:
                    json_object = json.loads(cleaned_text)  # Check if cleaned text is valid JSON
                    return cleaned_text
                except json.JSONDecodeError:
                    print("Failed to decode JSON. The API response may not be in valid JSON format.")
                    return None
            else:
                print("Generated text does not start or end as expected with markdown syntax.")
                return None
        else:
            print("No valid choices found in the response.")
            return None
    else:
        raise Exception(f"API request failed: {response.status_code} {response.text}")

def remove_duplicates(test_cases):
    """Removes duplicate test cases by converting them to a set of strings."""
    unique_tests = {json.dumps(tc, sort_keys=True): tc for tc in test_cases}
    return list(unique_tests.values())

def process_files(directory_path):
    """Processes each YAML file in the directory for generating test cases and saves them in separate files."""
    test_types = ["functional", "boundary", "error handling", "security", "performance"]
    
    try:
        for filename in os.listdir(directory_path):
            if filename.endswith('.yml') or filename.endswith('.yaml'):
                print(f"Processing file: {filename}")
                file_path = os.path.join(directory_path, filename)
                yaml_content = read_yaml_content(file_path)
                
                all_test_cases = []
                for test_type in test_types:
                    test_cases_text = generate_test_cases(yaml_content, test_type)
                    if test_cases_text:
                        try:
                            test_cases_json = json.loads(test_cases_text)
                            all_test_cases.extend(test_cases_json["test_cases"])
                        except json.JSONDecodeError:
                            print(f"Error decoding JSON for {filename} with test type {test_type}.")
                
                unique_test_cases = remove_duplicates(all_test_cases)
                
                output_file_path = os.path.join(directory_path, f"test_cases_for_{filename}.json")
                with open(output_file_path, 'w') as output_file:
                    json.dump({"test_cases": unique_test_cases}, output_file, indent=4)
                
                print(f"Generated and saved test cases for {filename}\n")
                
    except Exception as e:
        print(f"Error processing files: {e}")

if __name__ == "__main__":
    process_files(directory_path)