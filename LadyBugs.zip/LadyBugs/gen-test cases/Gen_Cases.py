import os
import requests
import json

# Set the directory where your YAML files are located
directory_path = "end-points"

# OpenRouter API details
api_key = "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"
base_url = "https://openrouter.ai/api/v1"
headers = {
    "Authorization": f"Bearer {api_key}",
}

def read_yaml_content(file_path):
    """Reads the entire content of a YAML file as a string."""
    with open(file_path, 'r') as file:
        return file.read()

def generate_test_cases(yaml_content, max_retries=3):
    """Sends YAML file content to the OpenAI API and returns generated test cases."""
    data = {
        "model": "openai/gpt-4o",
        "prompt": f"""ROLE: You are an API testing engineer assigned to write test cases. Instructions:
Create both positive and negative test cases.
Organize the test cases in a json format with the following columns: Test Case ID, Test Description, Input, Expected Output, and Remarks.
For positive test cases, ensure valid inputs and expected successful responses.
For negative test cases, include scenarios with invalid inputs and the expected error responses or status codes. Generate test cases based on the following YAML content:\n{yaml_content}   RETURN ONLY JSON FORMAT OR YOU WILL GET A PENALTY""",
        "temperature": 0.5
    }
    attempts = 0
    while attempts < max_retries:
        response = requests.post(f"{base_url}/completions", headers=headers, json=data)
        if response.status_code == 200:
            response_content = response.json()
            if "choices" in response_content and response_content["choices"]:
                generated_text = response_content["choices"][0]["text"]
                if generated_text.startswith("```json") and generated_text.endswith("```"):
                    cleaned_text = generated_text[7:-3].strip()
                    try:
                        json_object = json.loads(cleaned_text)  # Validate JSON format
                        return cleaned_text
                    except json.JSONDecodeError:
                        print("Failed to decode JSON. The API response may not be in valid JSON format.")
                else:
                    print("Generated text does not start or end as expected with markdown syntax.")
            else:
                print("No valid choices found in the response.")
        else:
            print(f"API request failed: {response.status_code} {response.text}")

        attempts += 1
        print(f"Attempt {attempts}/{max_retries} failed, retrying...")

    raise Exception("Failed to generate test cases after maximum retries.")

def process_files():
    """Processes each YAML file in the directory to generate test cases and saves them in separate files."""
    output_directory = os.path.join(directory_path, 'gen_tests')
    
    # Ensure the output directory exists
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)
    try:
        for filename in os.listdir(directory_path):
            if filename.endswith('.yml'):
                print(f"Processing file: {filename}")
                file_path = os.path.join(directory_path, filename)
                yaml_content = read_yaml_content(file_path)
                test_cases = generate_test_cases(yaml_content)
                
                if test_cases:
                    print(f"Raw test cases string: {test_cases}") 
                    try:
                        test_cases_json = json.loads(test_cases)
                    except json.JSONDecodeError as e:
                        print(f"Error decoding JSON for {filename}: {e}")
                        continue
                    
                    # Save the generated test cases in a JSON file
                    output_file_path = os.path.join(output_directory, f"test_cases_for_{filename}.json")
                    with open(output_file_path, 'w') as output_file:
                        json.dump(test_cases_json, output_file, indent=4)
                    print(f"Generated and saved test cases for {filename} in {output_directory}\n")
                else:
                    print(f"Failed to generate valid test cases for {filename}")
    except Exception as e:
        print(f"Error processing files: {e}")

if __name__ == "__main__":
    process_files()