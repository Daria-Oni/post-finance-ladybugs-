import subprocess
import logging

def run_pytest_and_generate_html_report():
    # Run pytest with parameters to generate HTML report
    command = [
        'cmd.exe', '/c',
        'pytest',
        'test_usecase_account.py',
        '--html=report_account.html',
        '--self-contained-html'
    ]

    # Run process
    result = subprocess.run(command, capture_output=True, text=True)

    # Logging of results
    logging.info(f'STDOUT: {result.stdout}')
    logging.error(f'STDERR: {result.stderr}')

    return result


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, filename='test_log_account.log')
    run_pytest_and_generate_html_report()
