import requests
import pytest
import json
import logging

# Setup basic logging to help with debugging
logging.basicConfig(level=logging.DEBUG, filename='test_log.log')

BASE_URL = "http://localhost:8080"

# Load test cases from a JSON file
def load_test_cases():
    with open("test-hack\\gen_tests\\test_cases_for_balance.yml.json", "r") as file:
        data = json.load(file)
        return data['test_cases']

# Load the test cases from the JSON file once
test_cases = load_test_cases()

# Use pytest to parameterize the function, creating a test for each case
@pytest.mark.parametrize("test_case", test_cases)
def test_retrieve_account_balance(test_case):
    url = f"{BASE_URL}/accounts/balance"
    headers = {'Authorization': test_case["Input"]["Authorization"]}

    # Log the test attempt
    logging.debug(f"Testing {test_case['Test Case ID']}: with Authorization expecting {test_case['Expected Output']['status']}")

    # Make the GET request
    response = requests.get(url, headers=headers)

    # Assert to check if the status code matches the expected status code
    assert response.status_code == test_case["Expected Output"]["status"], f"Expected status code {test_case['Expected Output']['status']}, got {response.status_code}"

    # Additional checks based on the expected output
    if response.status_code == 200:
        # Parse the response JSON for further validation
        response_data = response.json()
        # Assuming expected output includes multiple account details
        expected_body = test_case["Expected Output"]["body"]
        for expected_account in expected_body:
            assert any(account for account in response_data if account['iban'] == expected_account['iban'] and account['balance'] == expected_account['balance']), "Expected account data not found in response"
    else:
        # For error cases, check the error message
        response_data = response.json()
        assert response_data['error'] == test_case["Expected Output"]["error"], f"Expected error message '{test_case['Expected Output']['error']}', got '{response_data['error']}'"

