import requests
import pytest
import json
import logging

# Setup basic logging to help with debugging
logging.basicConfig(level=logging.DEBUG, filename='test_log.log')

BASE_URL = "http://localhost:8080"

# Load test cases from a JSON file
def load_test_cases():
    with open("test-hack\\gen_tests\\test_cases_for_password.yml.json", "r") as file:  # Ensure the path and file name are correct
        data = json.load(file)
        return data['test_cases']

# Load the test cases from the JSON file once
test_cases = load_test_cases()

# Use pytest to parameterize the function, creating a test for each case
@pytest.mark.parametrize("test_case", test_cases)
def test_change_password(test_case):
    url = f"{BASE_URL}/customers/password"
    input_data = test_case["Input"]
    expected_status_code = test_case["Expected Output"]["status"]

    # Log the test attempt
    logging.debug(f"Testing {test_case['Test Case ID']}: Sending data {input_data} expecting status {expected_status_code}")

    # Make the POST request
    response = requests.post(url, json=input_data)

    # Assert to check if the status code matches the expected status code
    assert response.status_code == expected_status_code, f"Expected status code {expected_status_code}, got {response.status_code}"

    # Validate the response body based on the expected outcome
    if response.status_code == 200:
        response_data = response.json()
        assert response_data['body'] == test_case["Expected Output"]["body"], f"Expected message '{test_case['Expected Output']['body']}', got '{response_data['body']}'"
    elif response.status_code in [400, 401]:
        response_data = response.json()
        assert response_data['body'] == test_case["Expected Output"]["body"], f"Expected error '{test_case['Expected Output']['body']}', got '{response_data['body']}'"
