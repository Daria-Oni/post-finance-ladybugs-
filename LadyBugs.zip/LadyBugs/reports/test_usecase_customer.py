import requests
import pytest
import json
import logging

# Setup basic logging to help with debugging
logging.basicConfig(level=logging.DEBUG, filename='test_log.log')

BASE_URL = "http://localhost:8080"

# Load test cases from a JSON file
def load_test_cases():
    with open("test-hack\\gen_tests\\test_cases_for_customer.yml.json", "r") as file: 
        data = json.load(file)
        return data['test_cases']

# Load the test cases from the JSON file once
test_cases = load_test_cases()

# Use pytest to parameterize the function, creating a test for each case
@pytest.mark.parametrize("test_case", test_cases)
def test_fetch_contact_info(test_case):
    input_details = test_case["Input"].split()
    method = input_details[0]  # GET or POST
    endpoint = input_details[1]  # Extract endpoint from input
    url = f"{BASE_URL}/support/contact"

    # Log the test attempt
    logging.debug(f"Testing {test_case['Test Case ID']}: {method} to {url} expecting status {test_case['Expected Output']}")

    # Determine the method to use
    if method == 'GET':
        response = requests.get(url)
    elif method == 'POST':
        response = requests.post(url)
    else:
        logging.error(f"Unsupported HTTP method {method} specified in test case")
        pytest.fail(f"Unsupported HTTP method {method}")

    # Assert to check if the status code matches the expected status code
    expected_status_code = int(test_case["Expected Output"].split()[2])  # Parsing the expected status from string
    assert response.status_code == expected_status_code, f"Expected status code {expected_status_code}, got {response.status_code}"

    # Additional validation to check if the response contains contact information
    if response.status_code == 200:
        response_data = response.json()
        assert 'ContactInformation' in response_data, "Contact information is missing in the response"
