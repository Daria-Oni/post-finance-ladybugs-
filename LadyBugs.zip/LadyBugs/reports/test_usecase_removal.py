import requests
import pytest
import json
import logging

# Setup basic logging to help with debugging
logging.basicConfig(level=logging.DEBUG, filename='test_log.log')

BASE_URL = "http://localhost:8080"

# Load test cases from a JSON file
def load_test_cases():
    with open("test-hack\\gen_tests\\test_cases_for_removal.yml.json", "r") as file:  # Corrected the file path
        data = json.load(file)
        return data['test_cases']

# Load the test cases from the JSON file once
test_cases = load_test_cases()

# Use pytest to parameterize the function, creating a test for each case
@pytest.mark.parametrize("test_case", test_cases)
def test_account_deletion(test_case):
    iban = test_case["Input"]["iban"]
    url = f"{BASE_URL}/accounts/{iban}"
    input_data = {key: test_case["Input"][key] for key in test_case["Input"] if key != 'Authorization'}
    headers = {'Authorization': test_case["Input"].get("Authorization", "")}  # Handling Authorization in headers

    # Log the test attempt
    logging.debug(f"Testing {test_case['Test Case ID']}: Deleting account with data {input_data} expecting status {test_case['Expected Output']['status_code']}")

    # Make the DELETE request, assuming that's the method used
    response = requests.delete(url, json=input_data, headers=headers)

    # Assert to check if the status code matches the expected status code
    assert response.status_code == test_case["Expected Output"]["status_code"], f"Expected status code {test_case['Expected Output']['status_code']}, got {response.status_code}"

    # Additional checks for response message
    if response.status_code == 200 or response.status_code == 400 or response.status_code == 401:
        response_data = response.json()
        assert response_data['response'] == test_case["Expected Output"]["response"], f"Expected response '{test_case['Expected Output']['response']}', got '{response_data['response']}'"

