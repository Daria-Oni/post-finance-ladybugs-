import requests
import pytest
import json
import logging

# Setup basic logging to help with debugging
logging.basicConfig(level=logging.DEBUG, filename='test_log.log')

BASE_URL = "http://localhost:8080"

# Load test cases from a JSON file
def load_test_cases():
    with open("test-hack\\gen_tests\\test_cases_for_account.yml.json.json", "r") as file:  # Corrected the file path to a more generic one
        data = json.load(file)
        return data['test_cases']

# Load the test cases from the JSON file once
test_cases = load_test_cases()

# Use pytest to parameterize the function, creating a test for each case
@pytest.mark.parametrize("test_case", test_cases)
def test_fetch_contact_info(test_case):
    input_details = test_case["Input"].split(' ', 2)  # Improved split to handle full input details properly
    method = input_details[0]  # GET or POST
    url = f"{BASE_URL}{input_details[1]}"  # Properly construct the URL with BASE_URL and the endpoint from the input

    # Log the test attempt
    logging.debug(f"Testing {test_case['Test Case ID']}: {method} to {url} expecting status {test_case['Expected Output']}")

    # Dynamic HTTP method handling
    response = requests.request(method, url)

    # Assert to check if the status code matches the expected status code
    expected_status_code = int(test_case["Expected Output"].split()[2])  # Parsing the expected status code from the description
    assert response.status_code == expected_status_code, f"Expected status code {expected_status_code}, got {response.status_code}"

    # Additional validation to check if the response matches the expected content for successful requests
    if response.status_code == 200:
        response_data = response.json()
        assert isinstance(response_data, list) and all('ContactInformation' in d for d in response_data), "Response data does not match expected ContactInformation objects"

