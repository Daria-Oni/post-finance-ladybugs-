import requests
import pytest
import json
import logging

# Setup basic logging to help with debugging
logging.basicConfig(level=logging.DEBUG, filename='test_log.log')

# Load test cases from a JSON file
def load_test_cases():
    with open("test-hack\\gen_tests\\test_cases_for_transaction.yml.json", "r") as file:  # Correct file path
        data = json.load(file)
        return data['test_cases']

# Load the test cases from the JSON file once
test_cases = load_test_cases()

# Use pytest to parameterize the function, creating a test for each case
@pytest.mark.parametrize("test_case", test_cases)
def test_transaction_history(test_case):
    url = test_case["Input"]["url"]  # Use URL from the test case
    headers = test_case["Input"].get("headers", {})  # Extract headers if present

    # Log the test attempt
    logging.debug(f"Testing {test_case['Test Case ID']}: {test_case['Input']['method']} to {url} expecting {test_case['Expected Output']['status_code']}")

    # Determine the method and make the request
    if test_case["Input"]["method"] == "GET":
        response = requests.get(url, headers=headers)
    elif test_case["Input"]["method"] == "POST":
        response = requests.post(url, headers=headers)
    else:
        logging.error(f"Unsupported HTTP method {test_case['Input']['method']} specified in test case")
        pytest.fail(f"Unsupported HTTP method {test_case['Input']['method']}")

    # Assert to check if the status code matches the expected status code
    assert response.status_code == test_case["Expected Output"]["status_code"], f"Expected status code {test_case['Expected Output']['status_code']}, got {response.status_code}"

    # Check the response body for the expected message or error
    response_data = response.json()
    if "body" in test_case["Expected Output"]:
        if isinstance(test_case["Expected Output"]["body"], dict):
            for key, expected_value in test_case["Expected Output"]["body"].items():
                assert response_data[key] == expected_value, f"Expected {key} to be {expected_value}, got {response_data[key]}"
        else:
            assert response_data == test_case["Expected Output"]["body"], f"Expected response '{test_case['Expected Output']['body']}', got '{response_data}'"

