import requests
import pytest
import json
import logging

# Set up basic logging to help with debugging
logging.basicConfig(level=logging.DEBUG, filename='test_log.log')

BASE_URL = "http://localhost:8080"

# Function to load test cases from a JSON file
def load_test_cases():
    with open("test-hack\\gen_tests\\test_cases_for_fund_transfer.yml.json", "r") as file:  # Updated to a more general file name
        data = json.load(file)
        return data

# Load the test cases from the JSON file once
test_cases = load_test_cases()

# Use pytest to parameterize the function, creating a test for each case
@pytest.mark.parametrize("test_case", test_cases)
def test_fund_transfer(test_case):
    url = f"{BASE_URL}/transactions/transfer"
    # Handling the Authorization header if present
    headers = {'Authorization': f"Bearer {test_case['Input'].get('Authorization', '')}"}
    # Exclude Authorization from the JSON body
    input_data = {key: value for key, value in test_case["Input"].items() if key != 'Authorization'}

    # Log the test attempt
    logging.debug(f"Testing {test_case['Test Case ID']}: Sending {input_data} with headers {headers} expecting {test_case['Expected Output']['status']}")

    # Make the POST request
    response = requests.post(url, json=input_data, headers=headers)

    # Assert to check if the status code matches the expected status code
    expected_status_code = test_case["Expected Output"]["status"]
    assert response.status_code == expected_status_code, f"Expected status code {expected_status_code}, got {response.status_code}"

    # Additional checks for successful transfer based on the expected status code
    if response.status_code == 200:
        # Parse the response JSON for further validation
        response_data = response.json()
        expected_body = test_case["Expected Output"]["body"]
        for key, value in expected_body.items():
            assert response_data.get(key) == value, f"Expected {key} to be {value}, got {response_data.get(key)}"
    elif response.status_code in [400, 401]:
        # Check for error messages
        response_data = response.json()
        assert response_data['error'] == test_case["Expected Output"]["body"]["error"], f"Expected error '{test_case['Expected Output']['body']['error']}', got '{response_data['error']}'"
